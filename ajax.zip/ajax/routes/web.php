<?php

use App\Http\Controllers\AdmissionController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('backend.dashboard');
});


// TEST
Route::get('/testview', [TestController::class, 'testview'])->name('testview');
Route::post('/test/store', [TestController::class, 'teststore'])->name('teststore');
Route::post('/test/edit/{id}', [TestController::class, 'edit'])->name('edit');
Route::put('/test/update/{id}', [TestController::class, 'update'])->name('update');
Route::post('/test/{id}', [TestController::class, 'destroy'])->name('destroy');
Route::get('/testview/getdata', [TestController::class, 'getData'])->name('getData');


//ADMISSION
Route::get('/addmission', [AdmissionController::class, 'index'])->name('admission');
Route::post('/addmission/store', [AdmissionController::class, 'store'])->name('admission.store');
Route::get('/addmission/getdata', [AdmissionController::class, 'getAdmissiondata'])->name('getAdmissiondata');
Route::post('/addmission/{id}', [AdmissionController::class, 'destroy'])->name('admission.destroy');


Route::get('/employee-add', [EmployeeController::class, 'employee'])->name('employee.view');

Route::post('/employee-store', [EmployeeController::class, 'store'])->name('employee.store');
Route::get('/employee-List', [EmployeeController::class, 'employeeList'])->name('employeeList');
Route::get('/employee-getdata', [EmployeeController::class, 'employeegetdata'])->name('employee.getdata');
Route::get('/employee-edit/{id}', [EmployeeController::class, 'edit'])->name('employee.edit');
Route::put('/employee-update/{id}', [EmployeeController::class, 'update'])->name('employee.update');
Route::delete('/employee-delete/{id}', [EmployeeController::class, 'destroy'])->name('employee.destroy');



// LEAVING_CERTIFICATE
defined('LEAVING_CERTIFICATE') or define('LEAVING_CERTIFICATE', public_path('/backend/admission/leaving_certificate'));

//MEDICAL_REPORT
defined('MEDICAL_REPORT') or define('MEDICAL_REPORT', public_path('/backend/admission/medical_report'));

//REPORT_CARD
defined('REPORT_CARD') or define('REPORT_CARD', public_path('/backend/admission/report_card'));
